//
//  RequestManager.swift
//  DirectoryApp
//
//  Created by MAC on 18/08/22.
//

import Foundation

protocol RequestManagerProtocol {
  func perform<T: Decodable>(_ request: RequestProtocol,  type: T.Type) async throws -> [T]
}

class RequestManager: RequestManagerProtocol {
  let apiManager: APIManagerProtocol
  init( apiManager: APIManagerProtocol = APIManager()) {
    self.apiManager = apiManager
  }

  func perform<T: Decodable>(
    _ request: RequestProtocol, type: T.Type) async throws -> [T] {
      let data = try await apiManager.perform(request)
        do {
          return  try JSONDecoder().decode([T].self, from: data)
        }catch {
            throw NetworkError.jsonParsingFailed
        }
  }
}
