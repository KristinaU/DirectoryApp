//
//  ServiceError.swift
//  DirectoryApp
//
//  Created by Ravali on 03/08/22.
//

import Foundation

enum NetworkError: Error {
    case invalidURL
    case invalidServerResponse
    case jsonParsingFailed
}
